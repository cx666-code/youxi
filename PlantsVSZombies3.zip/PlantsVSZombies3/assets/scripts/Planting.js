cc.Class({
    extends: cc.Component,

    properties: {
        score: {
            default: null,
            type: cc.Label
        },
        scoreCost: {
            default: null,
            type: cc.Label
        },

        plant: {
            default: null,
            type: cc.Prefab
        },

        UnCooling: {
            default: null,
            type: cc.SpriteFrame
        },

        Cooling: {
            default: null,
            type: cc.SpriteFrame
        },

        CoolingTime: 0,

    },

    onLoad: function () {
        this.Iscooling = 0;
        this.time = 0;
        this.cooltime = this.node.getChildByName("CoolingTime");
        this.scheduleOnce(function () {
            this.node.on(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);
        }, 10.5);
    },

    onDestroy: function () {
        this.node.off(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);

    },

    onMouseUp: function (event) {
        let mouseType = event.getButton();
        if (mouseType === cc.Event.EventMouse.BUTTON_LEFT) {
            if (!this.Iscooling) {
                this.LoseScore();
            }
        }
    },


    LoseScore: function () {
        if (Number(this.score.string) >= Number(this.scoreCost.string)) {
            this.score.string -= this.scoreCost.string;
            this.node.getComponent(cc.Sprite).spriteFrame = this.Cooling;
            this.cooltime.getComponent(cc.Label).string = this.CoolingTime;
            this.cooltime.opacity = 255;
            this.Iscooling = 1;
            var newplant = cc.instantiate(this.plant);
            newplant.getComponent('plant').Score = this;
            this.node.parent.parent.addChild(newplant);
            newplant.setPosition(this.node.x, this.node.y);
        }
    },

    GainScore: function () {
        var cost = Number(this.scoreCost.string);
        var sum = Number(this.score.string);
        sum += cost;
        this.score.string = sum;
    },

    update: function (dt) {
        if (this.Iscooling) {
            if (this.time > 1) {
                var T = Number(this.cooltime.getComponent(cc.Label).string);
                if (T == 0) {
                    this.Iscooling = 0;
                    this.node.getComponent(cc.Sprite).spriteFrame = this.UnCooling;
                    this.cooltime.opacity = 0;
                }
                T--;
                this.time = 0;
                this.cooltime.getComponent(cc.Label).string = T;
            }
            this.time += dt;
        }
    }
});

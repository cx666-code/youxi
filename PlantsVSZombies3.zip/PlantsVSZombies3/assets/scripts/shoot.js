cc.Class({
    extends: cc.Component,

    properties: {
        BulletPrefab: {
            default: null,
            type: cc.Prefab
        },

        ShootAudio: {
            default: null,
            type: cc.AudioClip
        },

        IsShoot: 0,

        Time: 0,
    },

    onLoad: function () {
        this.time = 0;
        this.time1 = 0;
    },

    spawnBulletPrefab: function () {
        var newBullet = cc.instantiate(this.BulletPrefab);
        cc.audioEngine.play(this.ShootAudio, false, 1);
        this.node.addChild(newBullet);
        newBullet.setPosition(this.node.width / 2, this.node.height / 4);
    },

    update: function (dt) {
        if (this.time > this.Time && this.IsShoot) {
            this.time = 0;
            this.spawnBulletPrefab();
        }
        if (this.time1 > 0.5) {
            this.time1 = 0;
            var newBullet = cc.instantiate(this.BulletPrefab);
            newBullet.opacity = 0;
            this.node.addChild(newBullet);
            newBullet.setPosition(this.node.width / 2, this.node.height / 4);
        }
        this.time += dt;
        this.time1 += dt;
    },
});

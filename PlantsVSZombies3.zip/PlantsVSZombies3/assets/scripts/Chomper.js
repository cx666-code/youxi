cc.Class({
    extends: cc.Component,

    properties: {
        ReadTime: 0,
        Blood: 0,
        Audio: {
            default: null,
            type: cc.AudioClip
        },
    },

    onLoad: function () {
        this.GamePoint = cc.find('Canvas/Score/Label');
        cc.director.getCollisionManager().enabled = true;
        this.Isread = 1;
        this.exit = 0;
        this.time = 0;
    },

    onCollisionStay: function (other, self) {
        var anim = this.node.getComponent(cc.Animation);
        let clips = anim.getClips();
        if (other.node.group == 'Zombie') {
            if (this.Isread) {
                this.Isread = 0;
                var animState = anim.play(clips[1].name);

                other.node.destroy();
                znum--;
                this.Point = Number(this.GamePoint.getComponent(cc.Label).string);
                this.Point += 10;
                this.GamePoint.getComponent(cc.Label).string = this.Point;
                this.scheduleOnce(function () {
                    animState = anim.play(clips[2].name);
                    //this.id =
                    cc.audioEngine.playEffect(this.Audio, false);
                }, 0.7);
                this.scheduleOnce(function () {
                    this.Isread = 1;
                    animState = anim.play();
                    //cc.audioEngine.stop(this.id);
                }, this.ReadTime);
                animState.wrapMode = cc.WrapMode.Loop;
                animState.repeatCount = Infinity;
            } else {
                this.Isattacked = 1;
                if (this.Blood == 0) {
                    this.node.destroy();
                    cc.audioEngine.stop(this.id);
                }
            }
        }
    },

    onCollisionExit: function (other, self) {
        if (other.node.group == 'Zombie') {
            this.Isattacked = 0;
        }
    },

    update: function (dt) {
        if (this.time > 1) {
            if (this.Isattacked) {
                this.Blood--;
            }
            this.time = 0;
        }
        this.time += dt;
    },
});

cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    Destroy:function(){
        this.node.destroy();
    },

});

cc.Class({
    extends: cc.Component,

    properties: {
        Shovel: {
            default: null,
            type: cc.Prefab
        },
    },

    onLoad: function () {
        this.scheduleOnce(function () {
            this.node.on(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);
        }, 8.5);
    },

    onDestroy: function () {
        this.node.off(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);

    },

    onMouseUp: function (event) {
        let mouseType = event.getButton();
        if (mouseType === cc.Event.EventMouse.BUTTON_LEFT) {
            if (!this.Iscooling) {
                this.LoseScore();
            }
        }
    },

    LoseScore: function () {
            var newplant = cc.instantiate(this.Shovel);
            this.node.parent.addChild(newplant);
            newplant.setPosition(this.node.x, this.node.y);
    },
});

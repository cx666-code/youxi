cc.Class({
    extends: cc.Component,

    properties: {
        Speed: 0,

        BulletAudio: {
            default: null,
            type: cc.AudioClip
        },
    },

    onLoad: function () {
        this.Speed1 = this.Speed;
        cc.director.getCollisionManager().enabled = true;
    },

    update: function (dt) {
        var shoot = this.node.parent.getComponent("shoot");
        if (this.node.opacity == 255) {
            this.node.x += this.Speed;
        }
        else if (this.node.opacity == 0) {
            this.node.x += 100;
        }
        if ((this.node.x + this.node.parent.x) > 480) {
            this.node.destroy();
            shoot.IsShoot = 0;
        }
    },

    onCollisionEnter: function (other) {
        var shoot = this.node.parent.getComponent("shoot");
        shoot.IsShoot = 1;
        if (this.node.opacity == 255) {
            cc.audioEngine.playEffect(this.BulletAudio, false);
        }

        this.node.destroy();
    },

});

cc.Class({
    extends: cc.Component,

    properties: {
        Speed: 0,

        cSpeed: 0,

        Blood: 0,

        PlantBlood: 0,

        HatBlood: 0,

        IsWall: 0,

        AudioButton: 0,

        Audio: {
            default: null,
            type: cc.AudioClip
        },


    },

    onLoad: function () {
        this.GamePoint = cc.find('Canvas/Score/Label');
        this.Speed1 = this.Speed;
        this.drophead = 0;
        this.attack = 0;
        this.drophat = 0;
        this.time = 0;
        this.Isattacked = 0;
        this.ReduceBlood = 0;
        this.num = 0;
        this.isBoom = 0;
        cc.director.getCollisionManager().enabled = true;
        this.anim = this.node.getComponent(cc.Animation);
        if (!this.HatBlood) {
            this.drophat = 1;
        }

        this.from1 = Math.floor(this.PlantBlood * 2 / 3);
        this.from2 = Math.floor(this.PlantBlood / 3);
    },

    start() {

    },

    update: function (dt) {
        this.node.x -= this.Speed;
        if (this.node.x < -450) {
            this.node.destroy();
            IsGameOver = 1;
        } else if (this.node.x > 500) {
            this.node.destroy();
        }
    },

    onCollisionEnter: function (other, self) {
        if (other.node.group == 'Bullet' && self.node.group == 'Zombie') {
            let clips = this.anim.getClips();
            var animState = this.anim;
            if (other.node.opacity == 255) {
                this.Blood--;
                if (this.Blood == 5 + this.HatBlood) {
                    if(!this.attack){
                        animState = this.anim.play(clips[4].name);
                    }else if(this.attack){
                        animState = this.anim.play(clips[2].name);
                    }
                    this.drophat = 1;
                }
                if (this.Blood == 5) {
                    var head = this.node.getChildByName("head");
                    if (!this.attack) {
                        animState = this.anim.play(clips[0].name);
                        this.scheduleOnce(function () {
                            head.opacity = 0;
                        }, 1);
                    }
                    else if (this.attack) {
                        animState = this.anim.play(clips[1].name);
                        this.scheduleOnce(function () {
                            head.opacity = 0;
                        }, 1);
                    }
                    animState.wrapMode = cc.WrapMode.Loop;
                    animState.repeatCount = Infinity;
                    this.drophead = 1;
                }
                if (this.Blood == 0) {
                    animState = this.anim.play(clips[7].name);
                    cc.audioEngine.stop(this.id);
                    self.node.group = 'default';
                    this.Speed -= this.Speed1;
                    this.scheduleOnce(function () {
                        self.node.destroy();
                        znum--;
                    }, 1.9);
                    this.Point = Number(this.GamePoint.getComponent(cc.Label).string);
                    this.Point += 10;
                    this.GamePoint.getComponent(cc.Label).string = this.Point;
                }
            }
        } else if (other.node.group == 'Plants' && self.node.group == 'Zombie') {

            let clips = this.anim.getClips();
            var animState = this.anim;
            this.Speed -= this.Speed1;
            this.attack = 1;
            this.anim = this.node.getComponent(cc.Animation);
            if (!this.drophead && this.drophat) {
                animState = this.anim.play(clips[2].name);
            }
            else if (this.drophead && this.drophat) {
                animState = this.anim.play(clips[3].name);
            } else if (!this.drophat) {
                animState = this.anim.play(clips[5].name);
            }
            this.id = cc.audioEngine.playEffect(this.Audio, true);
            animState.wrapMode = cc.WrapMode.Loop;
            animState.repeatCount = Infinity;
        }
        else if (other.node.group == 'car' && self.node.group == 'Zombie') {
            let clips = this.anim.getClips();
            animState = this.anim.play(clips[7].name);
            this.Point = Number(this.GamePoint.getComponent(cc.Label).string);
            this.Point += 10;
            this.GamePoint.getComponent(cc.Label).string = this.Point;
            this.Speed -= this.Speed1;
            this.scheduleOnce(function () {
                self.node.destroy();
                cc.audioEngine.stop(this.id);
                znum--;
            }, 1.9);
        } else if (other.node.group == 'Zombie' && self.node.group == 'car') {
            this.id = cc.audioEngine.playEffect(this.Audio, false, 0.5);
            if (self.node.x == -400) {
                carnum--;
            }
            if(this.cSpeed != 0){
                this.Speed += this.cSpeed;
            }
            this.cSpeed = 0;
            this.Point = Number(this.GamePoint.getComponent(cc.Label).string);
        } else if (other.node.group == 'boom' && self.node.group == 'Zombie') {
            this.isBoom = 1;
            let clips = this.anim.getClips();
            this.scheduleOnce(function () {
                animState = this.anim.play(clips[6].name);
                self.node.group = 'default';
                cc.audioEngine.stop(this.id);
                if(this.Speed != 0){
                    this.Speed -= this.Speed1;
                }
            }, 1.1);
            this.scheduleOnce(function () {
                self.node.destroy();
                this.Point = Number(this.GamePoint.getComponent(cc.Label).string);
                this.Point += 10;
                this.GamePoint.getComponent(cc.Label).string = this.Point;
                znum--;
            }, 3);
        } else if (other.node.group == 'Zombie' && self.node.group == 'Plants') {
            this.schedule(function () {
                this.PlantBlood--;
            }, 1);
        }
    },
    onCollisionStay: function (other, self) {
        if (self.node.group == 'Plants') {
            this.Isattacked = 1;
        }
        if (other.node.group == 'Zombie' && self.node.group == 'Plants') {
            let clips = this.anim.getClips();
            if (this.Isattacked) {
                if (this.IsWall) {
                    var animState
                    if (this.PlantBlood <= this.from1&&this.PlantBlood>this.from2) {
                        animState = this.anim.play(clips[1].name);
                        animState.wrapMode = cc.WrapMode.Loop;
                        animState.repeatCount = Infinity;
                    }
                    if (this.PlantBlood <= this.from2) {
                        animState = this.anim.play(clips[2].name);
                        animState.wrapMode = cc.WrapMode.Loop;
                        animState.repeatCount = Infinity;
                    }
                }
                if (this.PlantBlood <= 0) {
                    this.node.destroy();
                }
            }
        }
    },

    onCollisionExit: function (other, self) {
        if (other.node.group == 'Plants' && self.node.group == 'Zombie') {
            if (!this.isBoom) {
                let clips = this.anim.getClips();
                this.Speed += this.Speed1;
                if (!this.drophead && !this.drophat) {
                    this.anim.play();
                }
                else if (this.drophead) {
                    var head = this.node.getChildByName("head");
                    this.anim.play(clips[0].name);
                    head.opacity = 0;
                } else if (this.drophat) {
                    this.anim.play(clips[4].name);
                }
                cc.audioEngine.stop(this.id);
                this.attack = 0;
            }
        } else if (other.node.group == 'Zombie' && self.node.group == 'Plants') {
            this.Isattacked = 0;
        }
    },

});

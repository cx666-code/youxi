

cc.Class({
    extends: cc.Component,

    properties: {
        Audio: {
            default: null,
            type: cc.AudioClip
        },
    },


    onLoad:function () {
        var anim = this.node.getComponent(cc.Animation);
        anim.play();
        this.scheduleOnce(function () {
            cc.audioEngine.playEffect(this.Audio, false);
        }, 1);
        
        this.scheduleOnce(function () {
            this.node.destroy();
        }, 1.8);
    },

    start () {

    },

   
});

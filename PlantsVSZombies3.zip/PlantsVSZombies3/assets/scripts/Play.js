cc.Class({
    extends: cc.Component,

    properties: {

    },

    onLoad: function () {
        
        var anim = this.node.getComponent(cc.Animation);
        var animState = anim.play();
        animState.wrapMode = cc.WrapMode.Loop;
        animState.repeatCount = Infinity;
    },

    start() {
    },


});

cc.Class({
    extends: cc.Component,

    properties: {
        option:{
            default:null,
            type:cc.Node
        },
        pauseAudio:{
            default:null,
            type:cc.AudioClip
        }
    },
    onoption(event){
        this.option.setPosition(0,0);
        cc.audioEngine.playEffect(this.pauseAudio,false);
        cc.director.pause();
     },
     onrestart(event){
        cc.director.resume();
        cc.director.loadScene("game");
     },

     onback(event){
         cc.director.resume();
         cc.director.loadScene("startgame");
     },

    start () {
    },

});

cc.Class({
    extends: cc.Component,

    properties: {
        buttonsound:{
            default:null,
            type:cc.AudioClip
        },
    },

    onLoad:function(){
        this.node.zIndex = 1006;
    },

    outside(event){
        this.node.setPosition(-1200,-50);
        if(this.buttonsound){
        cc.audioEngine.playEffect(this.buttonsound,false);
        cc.director.resume();
        }
    },

    start () {

    },

});

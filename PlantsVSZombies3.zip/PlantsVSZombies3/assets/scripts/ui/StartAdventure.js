
cc.Class({
    extends: cc.Component,

    properties: {

        bleep:{
            default:null,
            type:cc.AudioClip
        },

    },

    start () {
        this.node.on(cc.Node.EventType.MOUSE_ENTER,function(){
            cc.audioEngine.playEffect(this.bleep,false);
        },this);
    },

});

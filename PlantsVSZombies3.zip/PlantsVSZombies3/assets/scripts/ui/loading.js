// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html


cc.Class({
    extends: cc.Component,

    properties: {
    },
     onclick(event){
         cc.director.loadScene("startgame");
     },

     onLoad:function(){
     },

    start () {

    },

});
cc.Class({
    extends: cc.Component,

    properties: {
        bgmcheck: {
            default: null,
            type: cc.Node
        },
        soundcheck: {
            default: null,
            type: cc.Node
        }
    },

    onLoad() {
        if (cc.audioEngine.getMusicVolume() == 1)
            this.bgmcheck.getComponent(cc.Toggle).isChecked = true;
        else
            this.bgmcheck.getComponent(cc.Toggle).isChecked = false;
        if (cc.audioEngine.getEffectsVolume() == 1)
            this.soundcheck.getComponent(cc.Toggle).isChecked = true;
        else
            this.soundcheck.getComponent(cc.Toggle).isChecked = false;
    },

    start() {

    },

});

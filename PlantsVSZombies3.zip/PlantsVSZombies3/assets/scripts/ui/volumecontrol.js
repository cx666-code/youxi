
cc.Class({
    extends: cc.Component,

    properties: {

    },



    onbgmcheck(toggle){
        if(toggle.isChecked){
        cc.audioEngine.setMusicVolume(1);
        }
        else{
        cc.audioEngine.setMusicVolume(0.001);
        }
     },

     onsoundcheck(toggle){
        if(toggle.isChecked){
        cc.audioEngine.setEffectsVolume(1);
        }
        else
        {
        cc.audioEngine.setEffectsVolume(0.001);
        }
     },


    start () {

    },

});

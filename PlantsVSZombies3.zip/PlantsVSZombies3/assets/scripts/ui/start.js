cc.Class({
    extends: cc.Component,

    properties: {
        bgm:{
            default:null,
            type:cc.AudioClip
        },
        startmusic:{
            default:null,
            type:cc.AudioClip
        },
        losemusic:{
            default:null,
            type:cc.AudioClip
        },
        tap:{
            default:null,
            type:cc.AudioClip
        },
        buttonclick:{
            default:null,
            type:cc.AudioClip
        },
        help:{
            default:null,
            type:cc.Node
        },
        option:{
            default:null,
            type:cc.Node
        },

        HistoryScore:{
            default:[],
            type:[cc.RichText]
        },

        challenge:{
            default:null,
            type:cc.Node
        },

        zombiehand:{
            default:null,
            type:cc.Node
        },
        bgmcheck:{
            default:null,
            type:cc.Node
        },
        soundcheck:{
            default:null,
            type:cc.Node
        }
    },
     onclicktostart(button){
        cc.audioEngine.stop(this.current);
        this.zombiehand.getComponent(cc.Animation).play();
        cc.audioEngine.playEffect(this.losemusic,false);
        this.scheduleOnce(function() {
            cc.audioEngine.playEffect(this.startmusic, false);
        }, 2);
        this.scheduleOnce(function() {
            cc.director.loadScene("game");
        }, 3);
     },



     onoption(event){
         cc.audioEngine.playEffect(this.tap,false);
        this.option.setPosition(0,0);
     },

     onchallenge(event){
        cc.audioEngine.playEffect(this.buttonclick,false);
         this.challenge.setPosition(0,0,);
     },

     onhelp(event){
        cc.audioEngine.playEffect(this.tap,false);
        this.help.setPosition(0,0);
     },
     onquit(event){
        cc.audioEngine.playEffect(this.tap,false);
        cc.director.loadScene("loading");
     },

     onLoad:function(){
        var key = new Array();
        key[0] = "first";
        key[1] = "second";
        key[2] = "third";
        key[3] = "forth";
        key[4] = "fifth";
        for(var i=0;i<5;i++){
            this.HistoryScore[i].getComponent(cc.RichText).string ="<color=#>第"+(i+1)+"名:"+cc.sys.localStorage.getItem(key[i])+"分</color>";
        }
        this.current = cc.audioEngine.playMusic(this.bgm, true,1);
     },

});

cc.Class({
    extends: cc.Component,

    properties: {
       time: 0,

       SunPrefab:{
        default:null,
        type:cc.Prefab
        },
    },

    onLoad:function(){
        this.timer = 0;
    },

    spawnSun:function(){
        var newSun = cc.instantiate(this.SunPrefab);
        this.node.addChild(newSun);
        this.timer = 0;
    },

    start () {

    },

    update:function (dt) {
        if(this.timer>this.time){
            this.spawnSun();
        }
        this.timer +=dt;
    },
});

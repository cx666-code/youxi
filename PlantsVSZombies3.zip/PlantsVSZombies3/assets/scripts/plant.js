cc.Class({
    extends: cc.Component,

    properties: {
        PlantsPrefab: {
            default: null,
            type: cc.Prefab
        },

        PlantAudio: {
            default: null,
            type: cc.AudioClip
        },
    },

    onLoad: function () {
        this.judge = 1;
        this.judge2 = 1;
        this.canvas = cc.find("Canvas");
        this.background = cc.find("Canvas/background1");
        this.canvas.on(cc.Node.EventType.MOUSE_MOVE, this.onMouseMove, this);
        this.node.on(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);
        cc.director.getCollisionManager().enabled = true;
    },
    onDestroy: function () {
        this.canvas.off(cc.Node.EventType.MOUSE_MOVE, this.onMouseMove, this);
        this.node.off(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);
    },


    onCollisionStay: function (other, self) {
        this.judge2 = 0;
    },

    onCollisionExit: function (other, self) {
        this.judge2 = 1;
    },

    onMouseMove: function (event) {
        if (this.judge) {
            var delta = event.getLocation();
            this.node.x = delta.x - (this.canvas.x);
            this.node.y = delta.y - (this.canvas.y);
        }
    },

    onMouseUp: function (event) {
        let mouseType = event.getButton();
        if (this.judge2) {
            if (this.node.x < 450 && this.node.x > -350 && this.node.y > -300 && this.node.y < 230) {
                if (mouseType === cc.Event.EventMouse.BUTTON_LEFT) {
                    var delta = event.getLocation();
                    this.judge = 0;
                    this.node.destroy();
                    var newplant = cc.instantiate(this.PlantsPrefab);
                    this.canvas.addChild(newplant);
                    cc.audioEngine.playEffect(this.PlantAudio, false);
                    var x = 110;
                    var i = Math.floor((delta.y - this.canvas.y-this.node.height/2) / x);
                    i = (i * 2 + 1) / 2;
                    newplant.y = x * i + this.node.height/4;
                    x = 89;
                    i = Math.floor((delta.x - this.canvas.x) / x);
                    i = (i * 2 + 1) / 2;
                    newplant.x = x * i;
                } else if (mouseType === cc.Event.EventMouse.BUTTON_RIGHT) {
                    this.Score.GainScore();
                    this.Score.cooltime.getComponent(cc.Label).string = 0;
                    this.node.destroy();
                }
            } else {
                this.Score.GainScore();
                this.Score.cooltime.getComponent(cc.Label).string = 0;
                this.node.destroy();
            }
        }
    },

    start() {
    },

});

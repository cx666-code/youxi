window.IsGameOver = 0;
window.IsWin = 0;
window.znum = 0;
window.carnum = 0;
cc.Class({
    extends: cc.Component,

    properties: {
        loadPrefab: {
            default: null,
            type: cc.Prefab
        },

        sunPrefab: {
            default: null,
            type: cc.Prefab
        },

        progressBar: {
            default: null,
            type: cc.ProgressBar
        },

        background: {
            default: null,
            type: cc.Node
        },

        scorePoint: {
            default: null,
            type: cc.Label
        },

        zomblePrefab: {
            default: [],
            type: [cc.Prefab]
        },

        SourceAudio: {
            default: null,
            type: cc.AudioClip
        },

        LookUpAudio: {
            default: null,
            type: cc.AudioClip
        },

        WinAudio: {
            default: null,
            type: cc.AudioClip
        },

        LoseAudio: {
            default: null,
            type: cc.AudioClip
        },

        ReadyAudio: {
            default: null,
            type: cc.AudioClip
        },
        sirenAudio: {
            default: null,
            type: cc.AudioClip
        },

        Gamepoint: {
            default: null,
            type: cc.Label
        },

        Finallypoint: {
            default: null,
            type: cc.Node
        },

        maxZombieDuration: 0,

        minZombieDuration: 0,

        maxSunDuration: 0,

        minSunDuration: 0,

        zombieCountin: 0,

        ProgressBarLoadTime: 0,
    },


    onLoad: function () {
        IsGameOver = 0;
        IsWin = 0;
        znum = 0;
        carnum = 5;
        this.Time = 0;
        this.key = new Array();
        this.key[0] = "first"; this.key[1] = "second"; this.key[2] = "third"; this.key[3] = "forth"; this.key[4] = "fifth";
        this.Gamepoint.node.zIndex = 1005;
        // for (var i = 0; i < 5; i++) {
        //     cc.sys.localStorage.setItem(this.key[i], 10 - i);
        // }
        this.groundY = this.background.y - this.background.height / 2;
        this.timer = 0;
        this.zombietimer = 0;
        this.sunDuration = 6;
        this.ZombleDuration = 6;
        this.score = 150;
        this.bar = 0;
        this.MainCamera = cc.find('Canvas/Main Camera');
        this.action = cc.moveTo(3, 400, this.MainCamera.y);
        this.MainCamera.runAction(this.action);
        this.scheduleOnce(function () {
            this.action = cc.moveTo(3, 0, this.MainCamera.y);
            this.MainCamera.runAction(this.action);
        }, 4);
        this.scheduleOnce(function () {
            var newload = cc.instantiate(this.loadPrefab);
            this.node.addChild(newload);
            newload.setPosition(0, 0);
            var anim = newload.getComponent(cc.Animation);
            cc.audioEngine.playEffect(this.ReadyAudio, false);
            anim.play();
        }, 8);
    },

    onDestroy: function () {
        cc.audioEngine.stop(this.current);
    },

    spawnNewSun: function () {
        let newSun = null;
        newSun = cc.instantiate(this.sunPrefab);
        newSun.zIndex = 1004;
        this.node.addChild(newSun);
        newSun.getComponent('Sun').game = this;
        newSun.setPosition(this.getNewSunPosition());
        this.sunDuration = this.minSunDuration + Math.random() * (this.maxSunDuration - this.minSunDuration);
        this.timer = 0;
    },

    getNewSunPosition: function () {
        var randX = 0;
        var randY = this.background.y + this.background.height / 2 - 33;
        var maxX = 650;
        randX = (Math.random() - 26 / 65) * maxX;
        return cc.v2(randX, randY);
    },

    spawnNewZombie: function () {
        znum++;
        var newZombie = null;
        var num = Math.floor(this.zomblePrefab.length * Math.random());
        if (num == this.zomblePrefab.length) {
            num--;
        }
        newZombie = cc.instantiate(this.zomblePrefab[num]);
        newZombie.zIndex = 1002;
        this.node.addChild(newZombie);
        newZombie.setPosition(this.getNewZombiePosition());
        this.ZombleDuration = (this.minZombieDuration + Math.random() *
            (this.maxZombieDuration - this.minZombieDuration)) * (0.2
                + 1 * (1 - this.progressBar.progress));
        this.zombietimer = 0;
    },

    getNewZombiePosition: function () {
        var zrandX = 0;
        var zrandY = this.background.height * 0.05 + Math.random() * this.background.height * 0.8;
        zrandX = 500;
        var x = 110;
        var i = Math.floor(zrandY / x);
        i = (i * 2 + 1) / 2;
        if (i > 5) {
            i = 4.5;
        }
        zrandY = x * i - 20;
        zrandY -= this.background.height * 0.38 + 15;
        return cc.v2(zrandX, zrandY);
    },

    start: function () {
        this.current = cc.audioEngine.playMusic(this.LookUpAudio, true, 1);
        var Pro = this.node.getChildByName("ProgressBar");
        var option = this.node.getChildByName("optionbutton");
        Pro.opacity = 0;
        option.opacity = 0;
        this.Gamepoint.node.opacity = 0;
        this.scheduleOnce(function () {
            Pro.opacity = 255;
            option.opacity = 255;
            this.Gamepoint.node.opacity = 255;
        }, 7.5);
        this.scheduleOnce(function () {
            this.sunbgein = 1;
            cc.audioEngine.stop(this.current);
            this.current = cc.audioEngine.playMusic(this.SourceAudio, true, 1);
            this.spawnNewSun();
        }, 11);
        this.scheduleOnce(function () {
            this.current = cc.audioEngine.playEffect(this.sirenAudio, false);
            this.spawnNewZombie();
            this.bar = 1;
        }, 41);
    },

    update: function (dt) {
        if (this.Time > 1) {
            this.Time = 0;
            if (IsGameOver) {
                IsGameOver = 0;
                cc.director.pause()
                this.current = cc.audioEngine.playMusic(this.LoseAudio, false, 1);
                var score = Number(this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string);
                score += carnum * 50;
                this.Finallypoint.zIndex = 1010;
                this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string = score;
                this.Finallypoint.getChildByName("Label2").getComponent(cc.Label).string = score;
                this.Finallypoint.x = 0;
                this.Finallypoint.y = 0;
                var n = 1;
                var ch = 0;
                for (var i = 0; i < 5; i++) {
                    if (n) {
                        var history = cc.sys.localStorage.getItem(this.key[i]);
                        if (Number(this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string) > history) {
                            cc.sys.localStorage.setItem(this.key[i], Number(this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string));
                            n = 0;
                        }
                    } else {
                        ch = cc.sys.localStorage.getItem(this.key[i]);
                        cc.sys.localStorage.setItem(this.key[i], history);
                        history = ch;
                    }
                }
            }

            if (IsWin && znum == 0) {
                znum = -1;
                this.scheduleOnce(function () {
                    this.current = cc.audioEngine.playMusic(this.WinAudio, false, 1);
                    var score = Number(this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string);
                    score += carnum * 50;
                    this.Finallypoint.zIndex = 1010;
                    this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string = score;
                    this.Finallypoint.getChildByName("Label2").getComponent(cc.Label).string = score;
                    this.Finallypoint.x = 0;
                    this.Finallypoint.y = 0;
                    var n = 1;
                    var ch = 0;
                    for (var i = 0; i < 5; i++) {
                        if (n) {
                            var history = cc.sys.localStorage.getItem(this.key[i]);
                            if (Number(this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string) > history) {
                                cc.sys.localStorage.setItem(this.key[i], Number(this.Gamepoint.node.getChildByName("Label").getComponent(cc.Label).string));
                                n = 0;
                            }
                        } else {
                            ch = cc.sys.localStorage.getItem(this.key[i]);
                            cc.sys.localStorage.setItem(this.key[i], history);
                            history = ch;
                        }
                    }
                }, 1);
            }
        }
        this.Time += dt;
        if (this.bar) {
            var progress = this.progressBar.progress;
            if (progress < 1) {
                progress += dt / this.ProgressBarLoadTime;
                this.progressBar.node.getChildByName("FlagMeterFull").getChildByName("FlagMeterParts1").x
                    = -this.progressBar.node.getChildByName("FlagMeterFull").width * (130 / 157);
            }
            else {
                progress = 1;
                IsWin = 1;
            }
            this.progressBar.progress = progress;
        }

        if (this.progressBar.progress < 1 && this.sunbgein) {
            if (this.timer > this.sunDuration) {
                this.spawnNewSun();
            }
            if (this.zombietimer > this.ZombleDuration && this.bar) {
                this.spawnNewZombie();
            }
            this.timer += dt;
            this.zombietimer += dt;

        }
    },

    gainScore: function () {
        this.score = Number(this.scorePoint.string);
        this.score += 25;
        this.scorePoint.string = this.score;
    },
});

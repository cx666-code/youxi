
cc.Class({
    extends: cc.Component,

    properties: {

    },

    onLoad: function () {
        this.judge2 = 0;
        this.canvas = cc.find("Canvas");
        this.canvas.on(cc.Node.EventType.MOUSE_MOVE, this.onMouseMove, this);
        this.node.on(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);
    },

    onDestroy: function () {
        this.canvas.off(cc.Node.EventType.MOUSE_MOVE, this.onMouseMove, this);
        this.node.off(cc.Node.EventType.MOUSE_UP, this.onMouseUp, this);
    },

    onCollisionStay: function (other, self) {
        if(this.judge2&&other.node.group == 'Plants'){ 
            other.node.destroy();
            //self.node.destroy();
        }
    },

    onMouseMove: function (event) {
        var delta = event.getLocation();
        this.node.x = delta.x - (this.canvas.x);
        this.node.y = delta.y - (this.canvas.y);
        this.judge2 = 0;
    },

    onMouseUp: function (event) {
        let mouseType = event.getButton();
        if (this.node.x < 450 && this.node.x > -350 && this.node.y > -300 && this.node.y < 230) {
            if (mouseType === cc.Event.EventMouse.BUTTON_LEFT) {
                this.judge2 = 1;
            } else if (mouseType === cc.Event.EventMouse.BUTTON_RIGHT) {
                this.node.destroy();
            }
        } else {
            this.node.destroy();
        }
    },
});

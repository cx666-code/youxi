"use strict";
cc._RF.push(module, '57323hChnNBR4r1vHp9TxFJ', 'Sun');
// scripts/Sun.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {

        downSpeed: 0,

        minsunDuration: 0,

        maxsunDuration: 0
    },

    onLoad: function onLoad() {
        this.n = 1;
        this.timer = 0;
        this.Sunback = cc.find('Canvas/SunBack');
        this.sunDuration = this.minsunDuration + Math.random() * (this.maxsunDuration - this.minsunDuration);
        this.sunstay = Math.random() * 467 - 240;
        this.node.on(cc.Node.EventType.MOUSE_DOWN, this.onMouseDown, this);
    },

    onDestroy: function onDestroy() {
        this.node.off(cc.Node.EventType.MOUSE_DOWN, this.onMouseDown, this);
    },

    update: function update(dt) {
        if (this.n) {
            if (this.node.y > this.sunstay) {
                this.node.y -= this.downSpeed;
            }
            if (this.timer > this.sunDuration) {
                this.node.destroy();
            }
            this.timer += dt;
        }
    },

    onClicked: function onClicked() {
        this.n = 0;
        var action = cc.moveTo(1, this.Sunback.x - this.Sunback.width / 2, this.Sunback.y);
        this.node.runAction(action);
        this.scheduleOnce(function () {
            this.node.destroy();
            this.game.gainScore();
        }, 1);
    },

    onMouseDown: function onMouseDown(event) {
        var mouseType = event.getButton();
        if (mouseType === cc.Event.EventMouse.BUTTON_LEFT) {
            this.onClicked();
        }
    }
});

cc._RF.pop();
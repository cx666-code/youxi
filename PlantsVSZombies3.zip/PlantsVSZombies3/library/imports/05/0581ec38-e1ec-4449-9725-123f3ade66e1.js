"use strict";
cc._RF.push(module, '0581ew44exESZclEj863mbh', 'Clip');
// scripts/Clip.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    Destroy: function Destroy() {
        this.node.destroy();
    }

});

cc._RF.pop();
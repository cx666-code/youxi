"use strict";
cc._RF.push(module, '4858ekOpylMo43CwJF3M9sx', 'Play');
// scripts/Play.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {

        var anim = this.node.getComponent(cc.Animation);
        var animState = anim.play();
        animState.wrapMode = cc.WrapMode.Loop;
        animState.repeatCount = Infinity;
    },

    start: function start() {}
});

cc._RF.pop();
"use strict";
cc._RF.push(module, '044feKiDJpNo5NH7GDz7aIC', 'Sun1');
// scripts/Sun1.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        minsunDuration: 0,

        maxsunDuration: 0
    },

    onLoad: function onLoad() {
        this.Sunback = cc.find('Canvas/SunBack');
        this.canvas = cc.find('Canvas');
        this.game = this.canvas.getComponent('Game');
        this.timer = 0;
        this.n = 1;
        this.node.x = 0;
        this.node.y = this.node.parent.height / 2;
        this.sunDuration = this.minsunDuration + Math.random() * (this.maxsunDuration - this.minsunDuration);
        this.sunstay = -2 - 524 / 2 + Math.random() * 524;
        this.node.opacity = 135;
        this.node.on(cc.Node.EventType.MOUSE_DOWN, this.onMouseDown, this);
    },

    onDestroy: function onDestroy() {
        this.node.off(cc.Node.EventType.MOUSE_DOWN, this.onMouseDown, this);
    },

    onClicked: function onClicked() {
        this.n = 0;
        var action = cc.moveTo(1, this.Sunback.x - this.node.parent.x - this.Sunback.width / 2, this.Sunback.y - this.node.parent.y);
        this.node.runAction(action);
        this.scheduleOnce(function () {
            this.node.destroy();
            this.game.gainScore();
        }, 1);
    },

    onMouseDown: function onMouseDown(event) {
        var mouseType = event.getButton();
        if (mouseType === cc.Event.EventMouse.BUTTON_LEFT) {
            this.onClicked();
        }
    },

    start: function start() {},


    update: function update(dt) {
        if (this.n) {
            if (this.node.x < 60) {
                this.node.x++;
                this.node.y = -(this.node.x + 9) * (this.node.x - 60) / 15;
                this.node.opacity += 3;
            }

            if (this.timer > this.sunDuration) {
                this.node.destroy();
            }
            this.timer += dt;
        }
    }
});

cc._RF.pop();
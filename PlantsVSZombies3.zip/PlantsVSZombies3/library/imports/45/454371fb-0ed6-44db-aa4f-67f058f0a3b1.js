"use strict";
cc._RF.push(module, '45437H7DtZE26pPZ/BY8KOx', 'volumecontrol');
// scripts/ui/volumecontrol.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onbgmcheck: function onbgmcheck(toggle) {
        if (toggle.isChecked) {
            cc.audioEngine.setMusicVolume(1);
        } else {
            cc.audioEngine.setMusicVolume(0.001);
        }
    },
    onsoundcheck: function onsoundcheck(toggle) {
        if (toggle.isChecked) {
            cc.audioEngine.setEffectsVolume(1);
        } else {
            cc.audioEngine.setEffectsVolume(0.001);
        }
    },
    start: function start() {}
});

cc._RF.pop();